#import os
import argparse
parser = argparse.ArgumentParser(description='Scrabble.')
parser.add_argument('chaine', metavar='string', type=str, nargs=1,
                            help='une chaine de caractere')

args = parser.parse_args()
mot=args.chaine[0] #les codes precedents permettent de saisir une chaine de caractere comme argument a partir de command prompt comme
if len(mot)>1 and len(mot)<=7: # on teste la longueur de la chaine entree par l'utilasateur,si ce n'est pas comprise entre ]1  7], c'est pas validee
 lis=[]
 #os.chdir("C:/Python27/sowpods")
 try:                             #on essaie d'ouvrir en lecture le fichier sowpods
        mon_fichier = open("sowpods.txt", "r")
 except:
        print "fichier non trouve"
 contenu = mon_fichier.read()
 lis=[]
 lis =contenu.split('\n')    # on met le contenu du fichier dans une liste nommee lis
 mon_fichier.close()
 scores = {"a": 1, "c": 3, "b": 3, "e": 1, "d": 2, "g": 2, 
         "f": 4, "i": 1, "h": 4, "k": 5, "j": 8, "m": 3,
         "l": 1, "o": 1, "n": 1, "q": 10, "p": 3, "s": 1,
         "r": 1, "u": 1, "t": 1, "w": 4, "v": 4, "y": 4,
         "x": 8, "z": 10}
 li=[]
 if mot=="":
        print"chaine doit etre non vide "
 rack=mot

    #rack=raw_input("Entrez une chaine de caracteres : ")
 rack=rack.upper()
 for mot in lis:     # on parcourt les mots de la liste nommee lis
      
        chaine = ''
        test = rack
        for lettre in mot:
                 
            if lettre in test: #si pour chaque mot,ses lettres se trouvent dans le rack qui vaut test
               chaine = '{}{}'.format(chaine,lettre) #on les met dans un string nomme chaine
               if mot.count(lettre)>test.count(lettre): #on la quantite de lettre dans le mot par rapport au rack
                  test = test.replace(lettre,'',1) #on enleve la lettre
                  
        if chaine==mot:              #si ce mot equivaut la chaine de tri
           li.append(chaine)         #on le met dans la liste des mots valides trouves
 if len(li)<=0:                      # si longueur de la liste des mots valides trouves serait inferieure ou egale a 0
              print '\n   mot non valide'   #on affiche la chaine saisie ne pas valide          
 som=0
 dic={}
 Liste_valeur=[]
 for mot in li: #pour chaque mot de la liste des mots valides trouves 
        for lettre in mot: #pour chaque lettre des mots valides trouves 
            for valeur,indice in scores.items(): #pour chaque lettre du dictionnaire scores et leur numero
                if lettre==valeur.upper(): #on fait un test pour s'assurer que la lettre du mot courant soit la meme pour le dict scores
                    som += indice          #on fait la somme de leur numero en la gardant dans un entier nomme som
        dic[mot]=som                       # on met le mot valide courant et la somme dans un dictionnaire nomme dic cree precedemment
        som=0                              #on remet la variable som a 0
        
 for value,index in dic.items():          #on parcourt le dictionnaire des mots valides et leur somme 
            Liste_valeur.append(index)    #on met les sommes dans une liste nomme Liste_valeur
 Liste_valeur.sort()                      #on fait un arrangement en ordre croissant
 Liste_valeur.reverse()                   #on fait le contraire de l'ordre croissant
 for indice in Liste_valeur:              #pour chaque valeur de la Liste_valeur
    for value,index in dic.items():       #pour chaque mot et somme du dict
    
     if index==indice:                    #si les somme tirees des deux cotes sont egales
      print("{}  {}".format(indice,value.lower()))  #on affiche les sommes
      dic.pop(value)                                #et puis on enleve ces sommes du dict

 print("\n{} words found ".format(len(li)))         #on calcule et affiche la longueur de la liste li contenant la quantite de mots valides trouves
 print '\n                  JOYEUX NOEL CHER DG !!!'
 print '\n                      Jean Waston THERANE de M1 base de donnees ESIH 2013-2014'
else: print "\n  2 caracteres au moins et 7 caracteres au plus !!! "    #message affiche a l'utilisateur si la chaine saisie n'est pas comprise entre ]1  7]
 
